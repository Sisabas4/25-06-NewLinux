#!/bin/bash

# Define module details
MODULE_NAME="e1000e"
MODULE_PATH="/lib/modules/$(uname -r)/kernel/drivers/net/ethernet/intel/${MODULE_NAME}/${MODULE_NAME}.ko"

# Check if the module file exists
if [[ ! -f "$MODULE_PATH" ]]; then
    echo "[!] Module file not found: $MODULE_PATH"
    exit 1
fi

# Insert the module using insmod
echo "[*] Inserting module: $MODULE_NAME"
sudo insmod "$MODULE_PATH"

# Verify if the module was loaded
if lsmod | grep -q "^${MODULE_NAME}"; then
    echo "[+] Module '${MODULE_NAME}' successfully loaded."
else
    echo "[!] Failed to load module '${MODULE_NAME}'."
    exit 1
fi

# Wait for user confirmation before cleanup
read -p "[*] Press ENTER to remove the module..."

# Unload the module
echo "[*] Removing module: $MODULE_NAME"
sudo rmmod "$MODULE_NAME"

# Confirm it was removed
if lsmod | grep -q "^${MODULE_NAME}"; then
    echo "[!] Module '${MODULE_NAME}' could not be removed."
else
    echo "[+] Module '${MODULE_NAME}' removed successfully."
fi
