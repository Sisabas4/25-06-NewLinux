#!/bin/bash

TEST_DIR="/tmp/immutable_test"
TEST_FILE="$TEST_DIR/sample.txt"

# Step 1: Create test directory and file
echo "[*] Creating test directory and file..."
mkdir -p "$TEST_DIR"
echo "This is an immutable test file." > "$TEST_FILE"

# Step 2: Apply immutable attribute
echo "[*] Applying immutable attribute..."
sudo chattr +i "$TEST_FILE"
sudo chattr +i "$TEST_DIR"

# Step 3: Verify immutable status
echo "[*] Verifying immutable status:"
lsattr "$TEST_FILE"
lsattr "$TEST_DIR"

# Step 4: Try modifying and deleting (should fail)
echo "[*] Trying to modify file (should fail):"
echo "Fail test" | tee -a "$TEST_FILE" || echo "[!] Modification blocked as expected."

echo "[*] Trying to delete file (should fail):"
rm "$TEST_FILE" 2>/dev/null || echo "[!] Deletion blocked as expected."

# Step 5: Remove immutable attributes
echo "[*] Removing immutable attributes..."
sudo chattr -i "$TEST_FILE"
sudo chattr -i "$TEST_DIR"

# Step 6: Verify removal
echo "[*] Verifying removal:"
lsattr "$TEST_FILE"
lsattr "$TEST_DIR"

# Step 7: Clean up
echo "[*] Now modifying and deleting (should work):"
echo "Success test" >> "$TEST_FILE"
rm "$TEST_FILE"
rmdir "$TEST_DIR"

echo "[+] Simulation complete: Immutable test handled successfully."
