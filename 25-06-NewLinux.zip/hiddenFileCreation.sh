#!/bin/bash

# Hidden directory and file
HIDDEN_DIR="$HOME/.hidden_dir"
HIDDEN_FILE="$HIDDEN_DIR/.hidden_file.txt"

echo "[*] Creating hidden directory: $HIDDEN_DIR"
mkdir -p "$HIDDEN_DIR"

echo "[*] Creating hidden file using 'touch': $HIDDEN_FILE"
touch "$HIDDEN_FILE"

echo "[*] Writing sample content..."
echo "This is a hidden file inside a hidden directory." > "$HIDDEN_FILE"

echo "[*] Listing hidden contents:"
ls -la "$HIDDEN_DIR"

# Optional: open in an editor
# vim "$HIDDEN_FILE"
# nano "$HIDDEN_FILE"

echo "[*] Sleeping for 3 seconds before deletion..."
sleep 3

echo "[*] Deleting hidden file and directory..."
rm -f "$HIDDEN_FILE"
rmdir "$HIDDEN_DIR" 2>/dev/null

if [[ ! -e "$HIDDEN_FILE" && ! -d "$HIDDEN_DIR" ]]; then
    echo "[+] Hidden file and directory deleted successfully."
else
    echo "[!] Deletion failed. Check permissions or usage."
fi
