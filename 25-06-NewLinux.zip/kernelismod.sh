#!/bin/bash

# Choose a safe Intel module
MODULE_PATH="/lib/modules/$(uname -r)/kernel/drivers/net/ethernet/intel/e1000e/e1000e.ko"

# Check if the module exists
if [[ -f "$MODULE_PATH" ]]; then
    echo "[*] Attempting to insert module: $MODULE_PATH"

    # Insert the module
    sudo insmod "$MODULE_PATH"

    # Check if it's loaded
    lsmod | grep e1000e && echo "[+] Module loaded successfully!" || echo "[!] Module did not load."
else
    echo "[!] Module not found at path: $MODULE_PATH"
fi
