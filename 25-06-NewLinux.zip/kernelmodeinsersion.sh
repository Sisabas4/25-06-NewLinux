#!/bin/bash

# Basic Kernel Module Simulation Script
# Usage: sudo ./simulate_module.sh /path/to/module.ko

MODULE_PATH="$1"

if [[ -z "$MODULE_PATH" ]]; then
    echo "[!] Usage: $0 /full/path/to/module.ko"
    exit 1
fi

MODULE_NAME=$(basename "$MODULE_PATH" .ko)

echo "[+] Trying to insert kernel module: $MODULE_NAME"

# Insert module
sudo insmod "$MODULE_PATH"

# Check if module is loaded
if lsmod | grep -q "^$MODULE_NAME"; then
    echo "[+] Module '$MODULE_NAME' loaded successfully!"
else
    echo "[!] Failed to load module '$MODULE_NAME'"
    exit 2
fi

echo "[*] Module Info:"
modinfo "$MODULE_PATH"

echo "[*] Currently loaded modules (top 5):"
lsmod | head -n 5

# Unload module (cleanup)
echo "[*] Unloading module after test..."
sudo rmmod "$MODULE_NAME"

if ! lsmod | grep -q "^$MODULE_NAME"; then
    echo "[+] Module '$MODULE_NAME' successfully removed."
else
    echo "[!] Failed to remove module '$MODULE_NAME'"
fi
