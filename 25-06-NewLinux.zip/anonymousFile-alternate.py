#!/usr/bin/env python3

import os
import ctypes

print("[*] Starting anonymous file execution simulation using fwupdmgr-style memfd_create...")

# Define memfd_create flags
MFD_CLOEXEC = 0x0001

# Load libc and syscall function
libc = ctypes.CDLL("libc.so.6")
libc.syscall.restype = ctypes.c_long

# syscall number for memfd_create on x86_64
SYS_memfd_create = 319

# Call memfd_create with the name "fwupdmgr"
fd = libc.syscall(SYS_memfd_create, b"fwupdmgr", MFD_CLOEXEC)
if fd < 0:
    print("[!] memfd_create failed.")
    exit(1)

# Write /bin/echo into the memory fd
with open("/bin/echo", "rb") as f:
    os.write(fd, f.read())

print("[*] Executing in-memory binary using fd:", fd)

# Replace current process with the in-memory binary
os.execv(f"/proc/self/fd/{fd}", ["fwupdmgr", "✅ In-memory execution using memfd_create"])
