#!/bin/bash

# masterSimulation.sh
# Executes a sequence of Bash scripts in order

set -uo pipefail  # Removed -e to prevent exit on error, but keep -u and -o pipefail for safety

SCRIPTS=(
  "accessing-etcPasswd.sh"
  "chattributeFile.sh"
  "dataComapressExfiltration.sh"
  "hiddenFileCreation.sh"
  "dsagent.sh"
  "kernelismod-removeincluded.sh"
  "SymlinkEtcPasswd.sh"
  "useraddgroup.sh"
  "cronJobSetup.sh"
  "gzip-nix-compress.sh"
  "hexDecodingUtility.sh"
  "xclipSimulation.sh"
  "loggingConfigurationChange.sh"
  "useraddgroup.sh --cleanup"
)

CLEANUP=false

if [[ "${1:-}" == "--cleanup" ]]; then
  CLEANUP=true
fi

echo "[START] Master Simulation Script"
echo "--------------------------------------"

for script in "${SCRIPTS[@]}"; do
  echo "[RUNNING] $script"
  if bash "$script"; then
    echo "[SUCCESS] Completed $script"
  else
    echo "[FAILURE] $script failed, continuing to next script"
  fi
  echo "--------------------------------------"
done

if $CLEANUP; then
  echo "[RUNNING] Cleanup via useraddgroup.sh --cleanup"
  if bash useraddgroup.sh --cleanup; then
    echo "[SUCCESS] Cleanup completed"
  else
    echo "[FAILURE] Cleanup failed"
  fi
fi

echo "[DONE] All scripts executed (with possible failures)"
