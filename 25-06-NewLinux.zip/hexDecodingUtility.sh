#!/bin/bash

echo "[*] Starting hex decoding simulation with xxd..."

# Original text
ORIGINAL_TEXT="suspicious_command_execution"
HEX_FILE="/tmp/encoded_hex.txt"
DECODED_FILE="/tmp/decoded_output.txt"
LOG_FILE="/tmp/hex_decode_simulation.log"

# Step 1: Convert text to hex
echo "[*] Encoding string to hex: $ORIGINAL_TEXT"
echo -n "$ORIGINAL_TEXT" | xxd -p > "$HEX_FILE"
ENCODED=$(cat "$HEX_FILE")
echo "[+] Hex encoded output: $ENCODED" | tee "$LOG_FILE"

# Step 2: Decode hex back to original using xxd -r -p
echo "[*] Decoding hex back to original..."
xxd -r -p "$HEX_FILE" > "$DECODED_FILE"
DECODED=$(cat "$DECODED_FILE")
echo "[+] Decoded output: $DECODED" | tee -a "$LOG_FILE"

# Verification
if [ "$DECODED" == "$ORIGINAL_TEXT" ]; then
    echo "[✓] Decode verification passed." | tee -a "$LOG_FILE"
else
    echo "[✗] Decode verification failed." | tee -a "$LOG_FILE"
fi

# Cleanup
echo "[*] Cleaning up temporary files..."
rm -f "$HEX_FILE" "$DECODED_FILE"

echo "[*] Simulation complete. Log saved at $LOG_FILE"
