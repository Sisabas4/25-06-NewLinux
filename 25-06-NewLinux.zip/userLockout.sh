#!/bin/bash

USERNAME="alabama"

echo "[*] Creating user: $USERNAME"
sudo useradd "$USERNAME" && echo "[+] User '$USERNAME' created."

echo "[*] Locking user account: $USERNAME"
sudo passwd -l "$USERNAME" && echo "[+] User '$USERNAME' account locked."

echo "[*] Waiting 5 seconds before deletion..."
sleep 5

echo "[*] Deleting user: $USERNAME"
sudo userdel -r "$USERNAME" && echo "[+] User '$USERNAME' deleted."
