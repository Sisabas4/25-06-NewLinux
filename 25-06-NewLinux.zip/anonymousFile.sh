#!/bin/bash

echo "[*] Starting anonymous in-memory execution simulation..."

# Create a memfd file and keep it open using a Python process
python3 - <<EOF
import os

fd = os.memfd_create("(sd-exec-strv)", os.MFD_CLOEXEC)
with open("/bin/echo", "rb") as f:
    os.write(fd, f.read())

# Create a temporary symlink to access the in-memory file (optional)
link_path = "/tmp/memfd_exec_link"
try:
    os.symlink(f"/proc/self/fd/{fd}", link_path)
    print(f"[*] Symlink created at: {link_path}")
except FileExistsError:
    os.remove(link_path)
    os.symlink(f"/proc/self/fd/{fd}", link_path)

# Execute the binary
os.execv(f"/proc/self/fd/{fd}", ["echo", "✅ Running from in-memory file via memfd_create"])
EOF

# After execution, control doesn't return here unless there's a failure
echo "[!] Execution did not happen. Something went wrong."
