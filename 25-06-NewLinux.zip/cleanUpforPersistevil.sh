#!/bin/bash
# Cleanup script to remove persistevil cron jobs

echo "Starting cleanup of persistevil cron jobs..."

FILES=(
  "/etc/cron.d/persistevil"
  "/etc/cron.daily/persistevil"
  "/etc/cron.hourly/persistevil"
  "/etc/cron.weekly/persistevil"
  "/etc/cron.monthly/persistevil"
)

for file in "${FILES[@]}"; do
  if [ -f "$file" ]; then
    echo "Removing $file"
    sudo rm -f "$file"
  else
    echo "$file not found, skipping."
  fi
done

# Optional: remove the log file
LOGFILE="/tmp/SISA.log"
if [ -f "$LOGFILE" ]; then
  echo "Removing $LOGFILE"
  sudo rm -f "$LOGFILE"
else
  echo "$LOGFILE not found, skipping."
fi

echo "Cleanup completed."
