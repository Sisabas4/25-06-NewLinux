#!/bin/bash

# ====== Configuration ======
SCRIPT_PATH="$HOME/testcron.sh"
LOG_PATH="$HOME/cronlog.txt"
CRON_JOB="*/2 * * * * $SCRIPT_PATH"

echo "[*] Creating script that will run via cron..."

# ====== Create the script ======
cat <<EOF > "$SCRIPT_PATH"
#!/bin/bash
echo "Job ran at \$(date)" >> "$LOG_PATH"
EOF

chmod +x "$SCRIPT_PATH"
echo "[+] Script created at $SCRIPT_PATH"

# ====== Install the cron job ======
echo "[*] Installing cron job to run every 2 minutes..."

# Check if job already exists
crontab -l 2>/dev/null | grep -qF "$SCRIPT_PATH"
if [ $? -eq 0 ]; then
    echo "[!] Cron job already exists. Skipping addition."
else
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    echo "[+] Cron job added: $CRON_JOB"
fi

# ====== Show current cron jobs ======
echo "[*] Current cron jobs:"
crontab -l

# ====== Info for the user ======
echo
echo "[✔] Setup complete."
echo "    -> Your cron job will run every 2 minutes."
echo "    -> Output will be logged to: $LOG_PATH"
echo "    -> To monitor: tail -f $LOG_PATH"
echo
echo "[✘] To remove the cron job and cleanup:"
echo "    crontab -l | grep -v '$SCRIPT_PATH' | crontab -"
echo "    rm -f '$SCRIPT_PATH' '$LOG_PATH'"
