#!/bin/bash

echo "[*] Starting simulation: Accessing /etc/passwd using various commands."

# 1. View using cat
echo "[*] Viewing with 'cat':"
cat /etc/passwd | head -n 3

# 2. View first 5 lines using head
echo "[*] Viewing with 'head -n 5':"
head -n 5 /etc/passwd

# 3. View last 5 lines using tail
echo "[*] Viewing with 'tail -n 5':"
tail -n 5 /etc/passwd

# 4. View using less (automated, no interaction)
echo "[*] Viewing with 'less' (first 5 lines):"
less /etc/passwd | head -n 5

# 5. View using vi (non-interactive for script)
echo "[*] Simulating 'vi' (non-interactive using ex command):"
ex -s +1p -c q /etc/passwd

# 6. View using nano (simulate open + close)
echo "[*] Simulating 'nano' open/close (without interaction)"
timeout 2s nano /etc/passwd 2>/dev/null

# 7. Copy the file to a temp location
echo "[*] Copying /etc/passwd to /tmp/passwd_copy"
cp /etc/passwd /tmp/passwd_copy

echo "[*] Showing copied file preview:"
head -n 3 /tmp/passwd_copy

# Clean up
echo "[*] Cleaning up copied file..."
rm -f /tmp/passwd_copy

echo "[+] Simulation complete."
