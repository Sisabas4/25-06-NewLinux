#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <errno.h>
extern char **environ; 
#ifndef MFD_CLOEXEC
#define MFD_CLOEXEC 0x0001
#endif

int main() {
    // Open ELF binary to read (e.g., /bin/ls or custom payload)
    int orig_fd = open("./memfd-runner", O_RDONLY);
    if (orig_fd < 0) {
        perror("open");
        exit(1);
    }

    // Create memfd
    int memfd = syscall(SYS_memfd_create, "anon_elf", MFD_CLOEXEC);
    if (memfd < 0) {
        perror("memfd_create");
        exit(1);
    }

    // Copy contents from file to memfd
    char buf[4096];
    ssize_t n;
    while ((n = read(orig_fd, buf, sizeof(buf))) > 0) {
        if (write(memfd, buf, n) != n) {
            perror("write");
            exit(1);
        }
    }
    close(orig_fd);

    // Execute in-memory ELF
    char *const argv[] = { "memfd-runner", NULL };
    fexecve(memfd, argv, environ);

    perror("fexecve");  // If we got here, it failed
    return 1;
}
