#!/bin/bash

# Set up
TMP_FILE="/tmp/xclip_simulation.txt"
CLIP_LOG="/tmp/xclip_clipboard_log.txt"

# Step 0: Ensure xclip is installed
if ! command -v xclip &> /dev/null; then
    echo "[!] xclip is not installed."
    read -p "[*] Install xclip now? (y/n): " confirm
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        echo "[+] Installing xclip..."
        sudo apt update && sudo apt install xclip -y
    else
        echo "[-] xclip is required. Exiting."
        exit 1
    fi
fi

# Step 1: Create a file with sample content
echo "[+] Creating temporary file with content..."
echo "Confidential: This is a simulation of xclip clipboard usage." > "$TMP_FILE"

# Step 2: Copy the content to clipboard
echo "[+] Copying content from $TMP_FILE to clipboard..."
xclip -selection clipboard "$TMP_FILE"

# Step 3: Simulate reading clipboard content
echo "[+] Reading content from clipboard into $CLIP_LOG..."
xclip -o -selection clipboard > "$CLIP_LOG"

# Step 4: Show result
echo "[+] Clipboard content retrieved:"
cat "$CLIP_LOG"

# Step 5: Wait for user input before cleanup
read -p "[*] Press ENTER to clean up temporary files..."

# Cleanup
rm -f "$TMP_FILE" "$CLIP_LOG"
echo "[+] Cleaned up: $TMP_FILE and $CLIP_LOG"
