#!/bin/bash

# Temporary directory and file
WORKDIR="/tmp/gzip_demo"
FILENAME="sample_data.txt"
FILEPATH="$WORKDIR/$FILENAME"
GZFILE="$FILEPATH.gz"

echo "[*] Setting up simulation environment..."
mkdir -p "$WORKDIR"

echo "[*] Creating test file: $FILEPATH"
echo "This is a demo file for gzip compression simulation." > "$FILEPATH"

echo "[*] Showing original file size:"
ls -lh "$FILEPATH"

echo "[*] Compressing file using gzip -k (keep original)..."
gzip -k "$FILEPATH"

echo "[*] Showing compressed file:"
ls -lh "$GZFILE"

echo "[*] Verifying both original and compressed exist:"
ls -l "$WORKDIR"

echo "[*] Sleeping 3 seconds before cleanup..."
sleep 3

echo "[*] Cleaning up files..."
rm -f "$FILEPATH" "$GZFILE"
rmdir "$WORKDIR" 2>/dev/null

if [[ ! -e "$FILEPATH" && ! -e "$GZFILE" ]]; then
    echo "[+] Compression simulation complete and cleaned up successfully."
else
    echo "[!] Cleanup failed — please check manually."
fi
