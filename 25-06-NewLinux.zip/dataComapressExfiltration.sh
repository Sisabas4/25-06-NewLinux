#!/bin/bash

# Setup
WORKDIR="/tmp/exfil_sim"
DATADIR="$WORKDIR/fake_data"
ARCHIVE="$WORKDIR/data_bundle.tar"
GZFILE="$ARCHIVE.gz"

echo "[*] Creating simulation environment..."
mkdir -p "$DATADIR"

# Create fake sensitive files
echo "[*] Creating fake sensitive files..."
echo "Internal credentials: admin:admin123" > "$DATADIR/creds.txt"
echo "Private SSH Key ---BEGIN--- ..." > "$DATADIR/id_rsa"
echo "Financial Report: Q1 2025 (confidential)" > "$DATADIR/finance.csv"

# Show file listing
echo "[*] Files prepared for compression:"
ls -lh "$DATADIR"

# Archive using tar
echo "[*] Archiving files with tar: $ARCHIVE"
tar -cf "$ARCHIVE" -C "$DATADIR" .

# Compress with gzip (optional for exfiltration)
echo "[*] Compressing archive with gzip: $GZFILE"
gzip -f "$ARCHIVE"  # creates data_bundle.tar.gz

# Show final compressed file
echo "[*] Final compressed file for exfiltration:"
ls -lh "$GZFILE"

# Sleep before cleanup
sleep 3

# Clean up
echo "[*] Cleaning up simulation files..."
rm -rf "$WORKDIR"

echo "[+] Simulation complete: Compression for possible exfiltration mimicked successfully."
