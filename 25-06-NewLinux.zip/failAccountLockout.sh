#!/bin/bash

USER="alabama"
echo "[*] Simulating 3 failed login attempts for user: $USER"

for i in {1..3}; do
    echo "[$i] Attempting invalid login..."
    echo "wrongpassword" | su -c "exit" "$USER" 2>/dev/null
    sleep 1
done

echo "[*] Checking faillock status..."
sudo faillock --user "$USER"

echo "[!] The user '$USER' should now be locked out after 3 bad logins."
