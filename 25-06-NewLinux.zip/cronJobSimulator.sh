#!/bin/bash

# cron_simulate.sh
# Simulate adding a cron job without using add_rule or auditctl

CRON_JOB="* * * * * /bin/echo 'Simulated malicious job ran at \$(date)' >> /tmp/malicious.log"
CRON_TMP_FILE="/tmp/temp_cron"

echo "[*] Backing up current cron jobs..."
crontab -l > "$CRON_TMP_FILE" 2>/dev/null

echo "[*] Appending simulated cron job..."
echo "$CRON_JOB" >> "$CRON_TMP_FILE"

echo "[*] Installing new cron jobs..."
crontab "$CRON_TMP_FILE"
rm "$CRON_TMP_FILE"

echo "[+] Cron job added. It will run every minute and write to /tmp/malicious.log"
echo "[+] You can check with: tail -f /tmp/malicious.log"
