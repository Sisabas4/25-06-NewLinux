#!/bin/bash

SIM_DIR="/etc"
mkdir -p "$SIM_DIR"

# Function to check and install a package if missing
install_if_missing() {
    local pkg=$1
    if ! command -v "$pkg" &> /dev/null; then
        echo "[!] $pkg is not installed. Installing..."
        if command -v apt-get &> /dev/null; then
            sudo apt-get update
            sudo apt-get install -y "$pkg"
        elif command -v yum &> /dev/null; then
            sudo yum install -y "$pkg"
        elif command -v pacman &> /dev/null; then
            sudo pacman -Sy --noconfirm "$pkg"
        else
            echo "[ERROR] Package manager not found. Please install $pkg manually."
            exit 1
        fi
    else
        echo "[*] $pkg is already installed."
    fi
}

# Check and install dependencies
install_if_missing vi
install_if_missing nano
install_if_missing xdotool

echo "[*] Starting simulation: just open and close with vi/nano..."

# Open and close /etc/syslog.conf with vi (simulated)
echo "[*] vi open/close: syslog.conf"
vi -c ':q' "${SIM_DIR}/syslog.conf"

# Open and close /etc/rsyslog.conf with nano (simulated)
echo "[*] nano open/close: rsyslog.conf"
( sleep 1; xdotool key Ctrl+x ) & nano "${SIM_DIR}/rsyslog.conf"

# Open and close /etc/syslog-ng/syslog-ng.conf with vi (simulated)
echo "[*] vi open/close: syslog-ng.conf"
vi -c ':q' "${SIM_DIR}/syslog-ng/syslog-ng.conf"

echo "[+] Simulation complete. Files opened and closed without editing."
