#!/bin/bash

echo "[*] Simulating Linux command history clearing..."

echo
echo "[1] Showing current shell history (last 5 commands):"
history | tail -n 5

echo
echo "[2] Unsetting HISTFILE (prevents writing to ~/.bash_history)"
unset HISTFILE
echo "    -> HISTFILE is now: '$HISTFILE' (should be empty)"

echo
echo "[3] Clearing in-memory shell history with: history -c"
history -c
echo "    -> Shell history cleared."

echo
echo "[4] Trying to list history after clearing:"
history  # Will likely show nothing

echo
echo "[✔] Simulation complete. No commands will be saved after this point in this shell."
