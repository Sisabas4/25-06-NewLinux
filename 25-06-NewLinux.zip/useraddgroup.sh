#!/bin/bash

USER="fakeuser"
GROUP="fakeadmin"

if [[ "$1" == "--cleanup" ]]; then
    echo "[*] Cleaning up..."
    
    # Remove user and their home directory
    userdel -r "$USER" 2>/dev/null && echo "[+] Removed user: $USER"
    
    # Remove the group
    groupdel "$GROUP" 2>/dev/null && echo "[+] Removed group: $GROUP"
    
    echo "[✓] Cleanup complete."
    exit 0
fi

echo "[*] Simulating user added to privileged group..."

# Create group if it doesn't exist
if ! getent group "$GROUP" > /dev/null; then
    groupadd "$GROUP"
    echo "[+] Group created: $GROUP"
fi

# Create user if it doesn't exist
if ! id "$USER" > /dev/null 2>&1; then
    useradd -m "$USER"
    echo "[+] User created: $USER"
fi

# Add user to the group
usermod -aG "$GROUP" "$USER"
echo "[+] User '$USER' added to group '$GROUP'"

echo "[✓] Simulation complete."
