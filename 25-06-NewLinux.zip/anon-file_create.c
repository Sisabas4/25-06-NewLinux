#define _GNU_SOURCE
#include <sys/syscall.h>
#include <sys/mman.h>       // For MFD_CLOEXEC
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    int fd = syscall(SYS_memfd_create, "demo", MFD_CLOEXEC);
    if (fd == -1) {
        perror("memfd_create");
        return 1;
    }

    FILE *in = fopen("/bin/echo", "rb");
    if (!in) {
        perror("fopen");
        return 1;
    }

    char buf[4096];
    size_t r;
    while ((r = fread(buf, 1, sizeof(buf), in)) > 0) {
        if (write(fd, buf, r) != r) {
            perror("write");
            fclose(in);
            return 1;
        }
    }
    fclose(in);

    // Execute the in-memory file
    char *const args[] = {"echo", "✅ Hello from memfd in C", NULL};
    fexecve(fd, args, environ);

    // If execution returns, something went wrong
    perror("fexecve");
    return 1;
}
