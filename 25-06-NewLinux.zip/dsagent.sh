#!/usr/bin/bash

systemctl stop ds_agent

systemctl restart ds_agent


