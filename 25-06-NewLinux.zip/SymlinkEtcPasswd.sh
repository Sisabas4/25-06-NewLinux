#!/bin/bash

set -e

# Define working directory and target
WORKDIR="$HOME/symlink_passwd_demo"
TARGET="/etc/passwd"
LINK1="$WORKDIR/passwd_link1"
LINK2="$WORKDIR/passwd_link2"

echo "[*] Creating working directory: $WORKDIR"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "[*] Cleaning any old links/files..."
rm -f "$LINK1" "$LINK2"

echo
echo "[1] Creating symbolic link WITHOUT -f"
ln -s "$TARGET" "$LINK1"
echo "    -> ln -s $TARGET $LINK1"
ls -l "$LINK1"

echo
echo "[2] Creating symbolic link WITH -f"
touch "$LINK2"
echo "    -> Created dummy file at $LINK2 to show -f overwrite"
ls -l "$LINK2"

ln -s -f "$TARGET" "$LINK2"
echo "    -> ln -s -f $TARGET $LINK2"
ls -l "$LINK2"

echo
echo "[*] Reading first 3 lines from each symlink:"
echo "---- $LINK1 ----"
head -n 3 "$LINK1"
echo "---- $LINK2 ----"
head -n 3 "$LINK2"

echo
echo "[*] Validating file types:"
file "$LINK1"
file "$LINK2"

echo
echo "[*] Cleanup: Removing links and working directory"
rm -f "$LINK1" "$LINK2"
rmdir "$WORKDIR"

echo "[✔] Simulation completed and cleaned up."
